@file:Suppress("DEPRECATION")

package com.example.bluetooth_app

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var titolo1: TextView
    private lateinit var titolo2: TextView
    private lateinit var myTextView1: TextView
    private lateinit var myTextView2: TextView
    private lateinit var myTextView3: TextView
    private lateinit var listView1: ListView
    private lateinit var listView2: ListView
    private lateinit var bluetoothAdapter: BluetoothAdapter
    private lateinit var deviceListAdapter1: ArrayAdapter<String>
    private lateinit var deviceListAdapter2: ArrayAdapter<String>
    private lateinit var connectedDevice: BluetoothDevice

    private val handler = Handler()
    private val requestEnableBluetooth = 1
    private val requestBluetoothPermission = 1001
    private val requestBluetoothAdminPermission = 1002
    private val scanDuration = 30000
    private var isScanning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) // Verifica il permesso di accesso alla posizione
            != PackageManager.PERMISSION_GRANTED)  {
            ActivityCompat.requestPermissions( // Richiede il permesso se non è stato concesso
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                requestBluetoothPermission
            )
        }

        // Verifica e richiede il permesso per l'accesso alla posizione in background per Android Q e versioni successive
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(baseContext,
                    Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION),
                    requestBluetoothPermission)
            }
        }

        initializeViews() // Inizializza le viste

        setupBluetooth() // Configura il Bluetooth

        setupPairedDevices() // Configura i dispositivi accoppiati

        setupListeners() // Configura i listener

        setupListViewClickListener() // aggiunta configurazione per il click sulla ListView1
    }

    private fun initializeViews() { // Inizializza le viste
        myTextView1 = findViewById(R.id.button1)
        myTextView2 = findViewById(R.id.button2)
        myTextView3 = findViewById(R.id.button3)
        listView1 = findViewById(R.id.listView1)
        listView2 = findViewById(R.id.listView2)
        deviceListAdapter1 = ArrayAdapter(this, android.R.layout.simple_list_item_1)
        deviceListAdapter2 = ArrayAdapter(this, android.R.layout.simple_list_item_1)
        listView1.adapter = deviceListAdapter1
        listView2.adapter = deviceListAdapter2
        titolo1 = findViewById(R.id.titolo1)
        titolo2 = findViewById(R.id.titolo2)
    }

    private fun setupBluetooth() { // Configura il Bluetooth
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter() // Ottiene l'adattatore Bluetooth predefinito

        if (bluetoothAdapter == null) { // Verifica se il dispositivo supporta il Bluetooth
            Toast.makeText(applicationContext, getString(R.string.not_support), Toast.LENGTH_LONG).show() // Mostra un messaggio se il Bluetooth non è supportato
            setContentView(R.layout.activity_main_blank) // Imposta il layout vuoto
        } else {
            if (bluetoothAdapter.isEnabled) {
                myTextView1.text = getString(R.string.off) // Imposta il testo del pulsante a "Spegni"
                showButtonAndListView(true) // Mostra i pulsanti e le viste della lista
            } else {
                myTextView1.text = getString(R.string.on) // Imposta il testo del pulsante a "Accendi"
                showButtonAndListView(false) // Nasconde i pulsanti e le viste della lista
            }
        }
    }

        private fun setupPairedDevices() {
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.BLUETOOTH_CONNECT) // Verifica il permesso per la connessione Bluetooth
                != PackageManager.PERMISSION_GRANTED)  {
                ActivityCompat.requestPermissions( // Richiede il permesso se non è stato concesso
                    this@MainActivity,
                    arrayOf(Manifest.permission.BLUETOOTH_CONNECT),
                    requestBluetoothPermission
                )
            }
            val pairedDevices: Set<BluetoothDevice>? = bluetoothAdapter.bondedDevices
            pairedDevices?.forEach { device ->
                val deviceName = device.name
                val deviceHardwareAddress = device.address
                if (BluetoothAdapter.checkBluetoothAddress(deviceHardwareAddress)) {
                    deviceListAdapter2.add("Name: $deviceName \nId: $deviceHardwareAddress")
                } else {
                    Log.e("MainActivity", "Invalid Bluetooth Address: $deviceHardwareAddress")
                }
            }
        }


        @SuppressLint("ClickableViewAccessibility")
    private fun setupListeners() { // Configura i listener
        myTextView1.setOnClickListener { // Listener per il pulsante "Accendi/Spegni"
            val text = myTextView1.text.toString() // Ottiene il testo del pulsante
            if (text == getString(R.string.on)) { // Se il testo è "Accendi"
                accendiBluetooth() // Accende il Bluetooth
                myTextView1.text = getString(R.string.off) // Imposta il testo del pulsante a "Spegni"
                showButtonAndListView(true) // Mostra i pulsanti e le viste della lista
            } else { // Altrimenti
                spegniBluetooth() // Spegne il Bluetooth
                myTextView1.text = getString(R.string.on) // Imposta il testo del pulsante a "Accendi"
                showButtonAndListView(false) // Nasconde i pulsanti e le viste della lista
            }
        }

        myTextView2.setOnClickListener { // Listener per il pulsante "Scansiona"
            if (!isScanning) {
                startBluetoothDiscovery() // Avvia la scansione Bluetooth
            }
        }

        myTextView3.setOnClickListener { // Listener per il pulsante "Visibile"
            myTextView3.text = getString(R.string.visible_active) // Imposta il testo del pulsante a "Visibile (attivo)"
            val discoverableIntent: Intent = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).apply { // Intent per rendere il dispositivo visibile
                putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300) // Imposta la durata della visibilità a 300 secondi
            }
            startActivity(discoverableIntent) // Avvia l'attività per rendere il dispositivo visibile
            handler.postDelayed({ // Delay per ripristinare il testo del pulsante dopo 315 secondi
                myTextView3.text = getString(R.string.visible) // Ripristina il testo del pulsante a "Visibile"
            }, 315000)
        }

        val filter = IntentFilter(BluetoothDevice.ACTION_FOUND) // IntentFilter per la ricezione dei dispositivi Bluetooth trovati
        registerReceiver(receiver, filter) // Registra il BroadcastReceiver per gestire l'evento di dispositivi trovati

        listView1.setOnTouchListener { _, _ -> // Listener per ListView1 per disabilitare lo scrolling sulla ScrollView
            findViewById<ScrollView>(R.id.scrollView).requestDisallowInterceptTouchEvent(true)
            false
        }

        listView2.setOnTouchListener { _, _ -> // Listener per ListView2 per disabilitare lo scrolling sulla ScrollView
            findViewById<ScrollView>(R.id.scrollView).requestDisallowInterceptTouchEvent(true)
            false
        }
    }

    private fun showButtonAndListView(show: Boolean) { // Mostra i pulsanti e le viste della lista
        val visibility = if (show) View.VISIBLE else View.GONE // Imposta la visibilità in base al parametro show
        myTextView2.visibility = visibility // Imposta la visibilità del pulsante "Scansiona"
        myTextView3.visibility = visibility // Imposta la visibilità del pulsante "Visibile"
        listView1.visibility = visibility // Imposta la visibilità della ListView1
        listView2.visibility = visibility // Imposta la visibilità della ListView2
        titolo1.visibility = visibility // Imposta la visibilità del titolo1
        titolo2.visibility = visibility // Imposta la visibilità del titolo2
    }

    private fun accendiBluetooth() { // Accende il Bluetooth
        if (!bluetoothAdapter.isEnabled) {
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE) // Intent per richiedere l'abilitazione del Bluetooth
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.BLUETOOTH
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions( // Richiede il permesso se non è stato concesso
                    this,
                    arrayOf(Manifest.permission.BLUETOOTH),
                    requestEnableBluetooth
                )
                return
            }
            startActivityForResult(enableBtIntent, requestEnableBluetooth) // Avvia l'attività per abilitare il Bluetooth
        } else { // Se il Bluetooth è già abilitato
            Toast.makeText(applicationContext, getString(R.string.already_on), Toast.LENGTH_LONG).show() // Mostra un messaggio che il Bluetooth è già attivo
        }
    }

    private fun spegniBluetooth() { // Spegne il Bluetooth
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.BLUETOOTH_ADMIN
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions( // Richiede il permesso se non è stato concesso
                this,
                arrayOf(Manifest.permission.BLUETOOTH_ADMIN),
                requestBluetoothAdminPermission
            )
            return
        }
        try {
            if (bluetoothAdapter.disable()) { // Disabilita il Bluetooth
                Toast.makeText(applicationContext, getString(R.string.bluetooth_off), Toast.LENGTH_LONG).show() // Mostra un messaggio che il Bluetooth è stato spento
                Log.d("MainActivity", "Bluetooth turned off successfully") // Log che il Bluetooth è stato spento con successo
            } else {
                Toast.makeText(applicationContext, getString(R.string.error), Toast.LENGTH_LONG).show() // Mostra un messaggio di errore
                Log.e("MainActivity", "Error turning off Bluetooth") // Log dell'errore nello spegnimento del Bluetooth
            }
        } catch (e: Exception) {
            Toast.makeText(applicationContext, "Error turning off Bluetooth: ${e.message}", Toast.LENGTH_LONG).show() // Mostra un messaggio di errore con la causa
            Log.e("MainActivity", "Error turning off Bluetooth", e) // Log dell'errore nello spegnimento del Bluetooth
        }
    }

    private fun startBluetoothDiscovery() { // Avvia la scansione Bluetooth
        deviceListAdapter1.clear() // Pulisce la lista dei dispositivi trovati
        isScanning = true // Imposta lo stato della scansione a true
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) // Verifica il permesso per la scansione Bluetooth
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions( // Richiede il permesso se non è stato concesso
                this,
                arrayOf(Manifest.permission.BLUETOOTH_SCAN),
                requestBluetoothPermission
            )
            return
        }
        if (bluetoothAdapter.startDiscovery()) { // Avvia la scansione Bluetooth
            myTextView2.text = getString(R.string.scaning) // Imposta il testo del pulsante "Scansiona" a "Scansione in corso"
            Toast.makeText(applicationContext, getString(R.string.scanning), Toast.LENGTH_LONG).show() // Mostra un messaggio che la scansione è in corso
            // Interrompe la scansione dopo scanDuration millisecondi
            listView1.postDelayed({ // Delay per fermare la scansione dopo scanDuration millisecondi
                bluetoothAdapter.cancelDiscovery() // Interrompe la scansione Bluetooth
                myTextView2.text = getString(R.string.scan) // Ripristina il testo del pulsante "Scansiona"
                isScanning = false // Imposta lo stato della scansione a false
                Toast.makeText(applicationContext, getString(R.string.scan_finished), Toast.LENGTH_LONG).show() // Mostra un messaggio che la scansione è terminata
            }, scanDuration.toLong())
        } else {
            Toast.makeText(applicationContext, getString(R.string.failed), Toast.LENGTH_LONG).show() // Mostra un messaggio di errore
            isScanning = false // Imposta lo stato della scansione a false
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) { // Funzione chiamata quando viene restituito un risultato da un'altra attività
        super.onActivityResult(requestCode, resultCode, data) // Chiama l'implementazione della superclasse
        if (requestCode == requestEnableBluetooth) { // Se il risultato è relativo alla richiesta di abilitazione del Bluetooth
            if (resultCode == RESULT_OK) { // Se l'utente ha accettato di abilitare il Bluetooth
                Toast.makeText(applicationContext, getString(R.string.bluetooth_on), Toast.LENGTH_LONG).show() // Mostra un messaggio che il Bluetooth è stato acceso
            } else { // Altrimenti
                Toast.makeText(applicationContext, getString(R.string.denied), Toast.LENGTH_LONG).show() // Mostra un messaggio che l'utente ha negato
                myTextView1.text = getString(R.string.on) // Imposta il testo del pulsante "Accendi"
                showButtonAndListView(false) // Nasconde i pulsanti e le viste della lista
            }
        }
    }

    override fun onDestroy() { // Funzione chiamata quando l'attività viene distrutta
        super.onDestroy() // Chiama l'implementazione della superclasse
        unregisterReceiver(receiver) // Deregistra il BroadcastReceiver
    }

    private val receiver = object : BroadcastReceiver() { // Definizione di un BroadcastReceiver per gestire l'evento di dispositivi trovati
        @RequiresApi(Build.VERSION_CODES.S)
        override fun onReceive(context: Context, intent: Intent) { // Funzione chiamata quando viene ricevuto un broadcast
            when(intent.action) { // Ottiene l'azione dell'intent
                BluetoothDevice.ACTION_FOUND -> { // Se l'azione è ACTION_FOUND (dispositivo Bluetooth trovato)
                    val device: BluetoothDevice? = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE) // Ottiene il dispositivo Bluetooth
                    val rssi: Short = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI, 0) // Ottiene il segnale RSSI del dispositivo
                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.BLUETOOTH_CONNECT) // Verifica il permesso per la connessione Bluetooth
                        != PackageManager.PERMISSION_GRANTED)  {
                        ActivityCompat.requestPermissions( // Richiede il permesso se non è stato concesso
                            this@MainActivity,
                            arrayOf(Manifest.permission.BLUETOOTH_CONNECT),
                            requestBluetoothPermission
                        )
                    }
                    val deviceName = device?.name // Ottiene il nome del dispositivo
                    val deviceHardwareAddress = device?.address // Ottiene l'indirizzo MAC del dispositivo
                    deviceListAdapter1.add("Name: $deviceName \nId: $deviceHardwareAddress \nRSSI: $rssi") // Aggiunge le informazioni del dispositivo all'adapter della lista
                }
            }
        }
    }
    private fun setupListViewClickListener() {
        listView1.onItemClickListener =
            AdapterView.OnItemClickListener { _, _, position, _ ->
                // Quando un elemento della lista viene cliccato
                val deviceInfo = listView1.getItemAtPosition(position) as String // Ottieni le informazioni del dispositivo cliccato
                val deviceHardwareAddress = deviceInfo.split("\n")[1].substring(4) // Ottieni l'indirizzo MAC del dispositivo cliccato

                // Connettiti al dispositivo cliccato
                connectToDevice(deviceHardwareAddress)
            }
    }

    private fun connectToDevice(deviceHardwareAddress: String) {
        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()

        // Ottieni il dispositivo Bluetooth dalla sua indirizzo MAC
        val device = bluetoothAdapter.getRemoteDevice(deviceHardwareAddress)

        // Effettua la connessione al dispositivo
        try {
            // Inizia una connessione asincrona al dispositivo
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.BLUETOOTH_CONNECT) // Verifica il permesso per la connessione Bluetooth
                != PackageManager.PERMISSION_GRANTED)  {
                ActivityCompat.requestPermissions( // Richiede il permesso se non è stato concesso
                    this@MainActivity,
                    arrayOf(Manifest.permission.BLUETOOTH_CONNECT),
                    requestBluetoothPermission
                )
            }
            val socket = device.createRfcommSocketToServiceRecord(device.uuids[0].uuid)
            socket.connect() // Connessione sincrona, può essere bloccante
            connectedDevice = device // Mantieni traccia del dispositivo attualmente connesso

            // Mostra gli ID dei servizi del dispositivo appena collegato
            val serviceIds = connectedDevice.uuids.map { it.uuid.toString() }
            showServiceIds(serviceIds)
        } catch (e: Exception) {
            Log.e("MainActivity", "Connection error: ${e.message}")
            Toast.makeText(applicationContext, "Connection error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showServiceIds(serviceIds: List<String>) {
        // Crea una stringa formattata con gli ID dei servizi separati da virgola
        val servicesString = serviceIds.joinToString(separator = "\n")

        // Mostra gli ID dei servizi nell'interfaccia utente
        Toast.makeText(applicationContext, "Service IDs:\n$servicesString", Toast.LENGTH_LONG).show()
    }
}
